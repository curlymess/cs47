let roundUp = 1.5
roundUp = Math.round(roundUp)
console.log(roundUp)