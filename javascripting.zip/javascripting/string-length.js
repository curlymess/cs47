const example = 'example string'
let len = example.length
console.log(len)