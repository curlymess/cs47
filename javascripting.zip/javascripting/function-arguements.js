function math ( first, second, third) {
    return second*third + first
}
console.log(math(53, 61, 67))